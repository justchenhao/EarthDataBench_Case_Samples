
LOCAL CLIMATOLOGICAL DATA (LCD) EXPLANATION FILE

This file explains how to read the monthly local climatological 
data (LCD) files.  These files are available for the period of 
record of January 1957 until present.  The file naming convention 
is MMYY.lcd, where MM = two digit month and YY = two digit year 
(i.e., 0997.lcd is the LCD file for September 1997).

On 01 January 1997, Amundsen-Scott South Pole Station redefined 
its climatological day as 0000-2359 Universal Coordinated Time 
(UTC).  With the exception of the three year period of 1994 
through 1996, this definition is consistent with South Pole
Station's meteorological record.

From January 1994 through December 1996, the climatological day
was defined as 0000-2359 New Zealand Standard Time. Daily data from these
years was reprocessed to use Universal Coordinated Time.

Another significant change affecting the LCD was the transition 
from Surface Aviation Observations (SAO) code to the World 
Meteorological Organization's (WMO) Aviation Routine Weather 
Report/Aviation Selected Special Weather (METAR/SPECI) code 
formats.  This transition occurred at 0000 UTC 01 June 1997.  

Affected by the METAR/SPECI transition were the symbols used 
for daily weather occurrences.  This change, as it affects the
LCD file, is detailed below.

Also, beginning with the June 1997 file, sky cover amounts
are reported in oktas (8ths), and not tenths (10ths).  

Daily maximum temperature: Minus degrees Celsius.

Daily minimum temperature: Minus degrees Celsius

Daily average temperature: Minus degrees Celsius.  The average
of all available observations for the day. This could range from
4 to 24 observations. Previously the daily average temperature had
been calculated as the average of the maximum and minimum temperatures.
All months have been reprocessed to use all available daily observations.

Precipitation:  Liquid equivalent, always recorded as a trace 
(T) after March 1958.  Liquid equivalent to the nearest one 
hundredth of an inch from January 1957 - March 1958.
No precipitation is recorded as a "0".

Daily average wind direction: Prevailing wind direction for the
day, i.e. the direction with the highest number of occurrences.
Wind direction observations are two-minute averages recorded to
the nearest ten degrees.  South Pole Station uses a grid system
in which 360 degrees corresponds to the prime meridian.

Daily average wind speed:  Average of twenty-four hourly
observations in miles per hour (mph) to the nearest tenth.  Each 
hourly observation is a two-minute average wind speed. 

Daily fastest mile (correctly labeled as Peak Wind beginning in
Jan. 2000):  This is the highest instantaneous speed in
miles per hour (mph), as obtained from the wind direction 
and speed recorder.

Daily fastest (peak) direction:  The grid direction of the highest 
instantaneous speed to the nearest ten degrees.

Daily Sunshine: Total sunshine to the nearest tenth of an hour. 
Estimated by suncards burned on a Campbell-Stokes sunshine
recorder.

Daily Sky Cover:  Average sky cover reported in tenths (oktas beginning
in June 1997).  The  average is based on four synoptic observations
daily from mid-February through late October.  During the austral summer, 
from November through mid-February, the value is the average of up to
twenty-four hourly observations daily.  Sky cover not only includes
opaque and translucent clouds, but also surface-based obscurations
(i.e., blowing snow, fog, etc.).

Daily station pressure:  Average station pressure in tenths of 
millibars (hPa), as computed from twenty-four hourly observations
daily.

Daily weather occurrences (WX):  Observed weather phenomena, 
including precipitation and obscurations.  No intensities.

From January 1957 through May 1997, SAO notations were used:

S - snow                        K - smoke
SG - snow grains                IF - ice fog          
SP - snow pellets               F - fog
IC - ice crystals               BS - blowing snow
SW - snow shower   
             
From June 1997 to present, METAR/SPECI notations are used:

SN - snow                       FU - smoke
SG - snow grains                FZFG - freezing fog 
GS - snow pellets               BR - mist (fog with vis 5/8 mile or more)
IC - ice crystals               BLSN - blowing snow
               
Other METAR/SPECI qualifiers may precede the precipitation or 
obscuration:

SH - shower
MI - shallow
PR - partial
BC - patches
VC - vicinity

Row 42: 
Average monthly maximum temperature:  Average of daily maximum
temperatures in minus degrees Celsius. 

Average monthly minimum temperature:  Average of daily minimum
temperatures in minus degrees Celsius.

Monthly average temperature:  Average of daily average temperatures
using all available observations. Minus degrees Celsius 

Average monthly wind direction: Prevailing grid wind direction,
i.e. the direction with the highest number of occurrences.   

Average monthly wind speed:  Average of the daily wind speeds 
in miles per hour (mph).

Monthly maximum instantaneous speed/Day of occurrence:  Maximum 
instantaneous wind speed (peak wind) in mph / day of occurrence. 

Average sunshine per day:  Average hours of sunshine per day 
to the nearest tenth of an hour.

Average monthly sky cover:  Average sky cover per day in tenths
(oktas beginning June 1997).

Average monthly station pressure:  Average station pressure to the 
nearest tenth of a millibar.  Computed by averaging the daily average
pressure values.

Row 44:
AVG MONTHLY: Average of daily average temperatures
using all available observations.  Degrees Celsius. (Same value
as line 42).

PCPN:  Monthly total precipitation.  Always recorded as a trace.

NR DAYS CLEAR:  Number of clear days (0-3 tenths or 0-2 oktas
sky coverage).

Row 45:
HIGHEST:  Maximum monthly temperature in degrees Celsius.

SUNSHINE: Total sunshine for the month, to the nearest 
tenth of an hour / percent of possible sunshine

PARTLY CLOUDY:  Number of partly cloudy days (4-7 tenths or
3-6 oktas sky coverage).

Row 46:
LOWEST: Minimum monthly temperature in degrees Celsius.

CLOUDY: Number of cloudy days (8-10 tenths or 7-8 oktas sky
coverage).

Row 47:
HIGH PRESSURE: Maximum monthly station pressure in millibars, 
followed by the day of occurrence.

Row 48 
LOW PRESSURE:  Minimum monthly station pressure in millibars,
followed by the day of occurrence.

Row 49:
NET CHANGE IN SNOWSTAKE FIELD:  Net average change in 
fifty snowstakes located approximately 1/2 mile grid 
southeast of station.  Reported in inches.  

Row 50:  
VECTORED WIND DIRECTION FOR THE MONTH: Reported to the nearest 
tenth of a degree.  Grid system used where 360 corresponds to 
the prime meridian.

Row 51:
VECTORED WIND SPEED FOR THE MONTH:  Reported to the nearest tenth 
of a knot.

            












